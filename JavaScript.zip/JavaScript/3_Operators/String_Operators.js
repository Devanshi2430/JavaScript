let s1 = "Devanshi";
let s2 = "Panchal";
let s3 = s1 + " " + s2;
document.write(s3);