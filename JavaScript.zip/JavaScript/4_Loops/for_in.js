const Human = {FirstName:"Devanshi", LastName:"Panchal", age:23};
for (let H in Human) {
    document.write("<br/>"+H);
  }
document.write("<hr/>");
for (let H in Human) {
  document.write("<br/>"+Human[H]);
}